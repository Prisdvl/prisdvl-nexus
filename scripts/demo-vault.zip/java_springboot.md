---
title: Spring Boot 自动配置
tags: [Java, SpringBoot]
---

# Spring Boot 自动配置

## 条件装配

Spring Boot 通过 @Conditional 系列注解决定某个 Bean 是否装配。参见 [[JVM 笔记]] 与 [[SpringMVC]]。

```java
@SpringBootApplication
public class App { }
```

## 起步依赖

starter 把一组常用依赖打包，避免手写版本号。