---
tags: [Java, JVM]
---

# JVM 笔记

## G1 收集器

G1 把堆划分成 Region，按收益优先回收。